/**
 * Created by hoho on 2018. 6. 29..
 */
export const version = __VERSION__;
