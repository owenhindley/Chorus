export default (uiText) => {
    return `<div class="op-spinner-container"><div class="op-spinner"></div></div>`;
};
